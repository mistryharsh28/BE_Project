#!/usr/bin/env bash

java -Xmx1500m -cp question-generation.jar edu/cmu/ark/SentenceSimplifier

